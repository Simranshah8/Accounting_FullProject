﻿app.controller('BankDOController', function ($scope, $http, $timeout, $filter, GlobalServices) {
    $scope.Title = 'Bank DO';
    var glSrv = GlobalServices;
    LoadData();

    $scope.sideBarData = [];
    $scope.SelectedVoucher = null;
    $scope.SelectedCostClass = null;
    function LoadData() {

        $scope.paginationOptions = {
            pageNumber: 1,
            pageSize: glSrv.getPerPageRow(),
            sort: null,
            SearchType: 'text',
            SearchCol: '',
            SearchVal: '',
            SearchColDet: null,
            pagearray: [],
            pageOptions: [5, 10, 20, 30, 40, 50]
        };
        $scope.VoucherSearchOptions = [{ text: 'EngineNo', value: 'TS.EngineNo', searchType: 'text' }, { text: 'PartyName', value: 'TS.PartyName', searchType: 'text' }, { text: 'MobileNo', value: 'TS.MobileNo', searchType: 'text' }, { text: 'PartyAddress', value: 'TS.PartyAddress', searchType: 'text' }, { text: 'BankName', value: 'TS.BankName', searchType: 'text' }, { text: 'Quotation No.', value: 'TS.AutoManualNo', searchType: 'text' }, { text: 'Voucher', value: 'V.VoucherName', searchType: 'text' }, { text: 'CostClass', value: 'CC.Name', searchType: 'text' }, { text: 'VoucherDate', value: 'TS.VoucherDate', searchType: 'date' }, { text: 'Amount', value: 'TS.TotalAmount', searchType: 'number' }];


        $scope.beData = {
            TranId: 0,
            BankQuotationTranId: null,
            QuotationNo: '',            
            VoucherId: null,
            CostClassId: null,
            AutoVoucherNo: 0,
            AutoManualNo: '',
            VoucherDate: new Date(),
            VoucherDateDet: new Date(),
            BankName: '',
            BankBranch: '',
            PartyName: '',
            PartyAddress: '',
            MobileNo: '',
            Model: '',
            Narration: '',
            Price: 0,
            DiscountAmt: 0,
            TotalAmount: 0,
            DoRefNo: '',
            AttechFiles: []
        };

        $scope.VoucherTypeColl = [];
        $scope.CostClassColl = [];
        $scope.VehicleModuleColl = [];

        $('.select2').select2({ allowClear: true, width: '100%', placeholder: 'select..' });

        if (VoucherType) {
            $timeout(function () {
                $http({
                    method: 'GET',
                    url: base_url + "Account/Creation/GetVoucherList?voucherType=" + VoucherType,
                    dataType: "json"
                }).then(function (res) {
                    if (res.data.IsSuccess && res.data.Data) {
                        $scope.VoucherTypeColl = res.data.Data;
                        $timeout(function () {
                            if ($scope.VoucherTypeColl.length > 0) {
                                $scope.SelectedVoucher = $scope.VoucherTypeColl[0];
                                $scope.beData.VoucherId = $scope.VoucherTypeColl[0].VoucherId;
                            }
                        });

                        $timeout(function () {
                            $scope.$apply(function () {
                                $scope.getVoucherNo();
                            });
                        });
                    }
                }, function (reason) {
                    alert('Failed' + reason);
                });
            });

            $timeout(function () {
                $http({
                    method: 'GET',
                    url: base_url + "Account/Creation/GetCostClassForEntry",
                    dataType: "json"
                }).then(function (res) {
                    if (res.data.IsSuccess && res.data.Data) {
                        $scope.CostClassColl = res.data.Data;

                        $timeout(function () {
                            if ($scope.CostClassColl.length > 0) {
                                $scope.SelectedCostClass = $scope.CostClassColl[0];
                                $scope.beData.CostClassId = $scope.CostClassColl[0].CostClassId;
                            }

                        });

                        $timeout(function () {
                            $scope.$apply(function () {
                                $scope.getVoucherNo();
                            });
                        });

                    }
                }, function (reason) {
                    alert('Failed' + reason);
                });
            });

            $http({
                method: 'GET',
                url: base_url + "Service/Creation/GetVehicleModelList",
                dataType: "json"
            }).then(function (res) {
                if (res.data.IsSuccess && res.data.Data) {
                    $scope.VehicleModuleColl = res.data.Data;
                }
            }, function (reason) {
                alert('Failed' + reason);
            });

        }


        $timeout(function () {
            $('#cboVoucherType').focus();
        })

    }
    $scope.ShowSideBar = function () {
        $('#sidebarzz').toggleClass('active');
    };

    $scope.OnPartyLoad = function () {
        // $scope.loadingstatus = 'running';
    };

    $scope.OnProductLoad = function () {

        // $scope.loadingstatus = 'running';
    };

    $scope.AddBankQuotation = function () {

        $scope.loadingstatus = "running";
        showPleaseWait();

        if ($scope.beData.VoucherDateDet) {

            if (moment($scope.beData.VoucherDateDet).isValid())
                $scope.beData.VoucherDate = $filter('date')(new Date($scope.beData.VoucherDateDet), 'yyyy-MM-dd');
            else
                $scope.beData.VoucherDate = $filter('date')(new Date($scope.beData.VoucherDateDet.dateAD), 'yyyy-MM-dd');
        }

        $scope.beData.DODate = $scope.beData.VoucherDate;

        var filesColl = $scope.beData.AttechFiles;
        $scope.beData.AttechFiles = [];
         
        $http({
            method: 'POST',
            url: base_url + "Inventory/Transaction/SaveUpdateBankDO",
            headers: { 'Content-Type': undefined },

            transformRequest: function (data) {

                var formData = new FormData();
                formData.append("jsonData", angular.toJson(data.jsonData));

                if (data.files) {
                    for (var i = 0; i < data.files.length; i++) {
                        formData.append("file" + i, data.files[i]);
                    }
                }

                return formData;
            },
            data: { jsonData: $scope.beData, files: filesColl }
        }).then(function (res) {

            $scope.loadingstatus = "stop";
            hidePleaseWait();

            alert(res.data.ResponseMSG);

            if (res.data.IsSuccess == true) {

                $scope.lastTranId = res.data.Data.RId;

                if ($scope.SelectedVoucher.PrintVoucherAfterSaving == true)
                    $scope.Print();

                $scope.Clear();
                $('#txtQuotationNo').focus();
            }

        }, function (errormessage) {
            hidePleaseWait();
            $scope.loadingstatus = "stop";

        });

    }

    $scope.Print = function () {
        if ($scope.lastTranId && $scope.lastTranId > 0) {
            var TranId = $scope.lastTranId;

            $http({
                method: 'GET',
                url: base_url + "ReportEngine/GetReportTemplates?entityId=" + EntityId + "&voucherId=" + $scope.SelectedVoucher.VoucherId + "&isTran=true",
                dataType: "json"
            }).then(function (res) {
                if (res.data.IsSuccess && res.data.Data) {
                    var templatesColl = res.data.Data;
                    if (templatesColl && templatesColl.length > 0) {
                        var templatesName = [];
                        var sno = 1;
                        angular.forEach(templatesColl, function (tc) {
                            templatesName.push(sno + '-' + tc.ReportName);
                            sno++;
                        });

                        var printed = false;
                        var rptTranId = 0;
                        if (templatesColl.length == 1)
                            rptTranId = templatesColl[0].RptTranId;
                        else {
                            Swal.fire({
                                title: 'Report Templates For Print',
                                input: 'select',
                                inputOptions: templatesName,
                                inputPlaceholder: 'Select a template',
                                showCancelButton: true,
                                inputValidator: (value) => {
                                    return new Promise((resolve) => {
                                        if (value >= 0) {
                                            resolve()
                                            rptTranId = templatesColl[value].RptTranId;
                                            printed = true;
                                            if (rptTranId > 0) {
                                                document.body.style.cursor = 'wait';
                                                document.getElementById("frmRpt").src = '';
                                                document.getElementById("frmRpt").src = base_url + "web/ReportViewer.aspx?rpttranid=" + rptTranId + "&istransaction=true&entityid=" + EntityId + "&voucherid=" + $scope.SelectedVoucher.VoucherId + "&tranid=" + TranId + "&vouchertype=" + VoucherType;
                                                document.body.style.cursor = 'default';
                                                $('#FrmPrintReport').modal('show');
                                            }
                                        } else {
                                            resolve('You need to select:)')
                                        }
                                    })
                                }
                            })
                        }

                        if (rptTranId > 0 && printed == false) {
                            document.body.style.cursor = 'wait';
                            document.getElementById("frmRpt").src = '';
                            document.getElementById("frmRpt").src = base_url + "web/ReportViewer.aspx?rpttranid=" + rptTranId + "&istransaction=true&entityid=" + EntityId + "&voucherid=" + $scope.SelectedVoucher.VoucherId + "&tranid=" + TranId + "&vouchertype=" + VoucherType;
                            document.body.style.cursor = 'default';
                            $('#FrmPrintReport').modal('show');
                        }

                    } else
                        Swal.fire('No Templates found for print');
                }
            }, function (reason) {
                Swal.fire('Failed' + reason);
            });



        }
    };
    $scope.getVoucherNo = function () {
        if ($scope.beData.VoucherId && $scope.beData.VoucherId > 0) {
            if ($scope.beData.CostClassId && $scope.beData.CostClassId > 0) {
                var para = {
                    voucherId: $scope.beData.VoucherId,
                    costClassId: $scope.beData.CostClassId,
                    voucherDate: $scope.beData.VoucherDateDet ? ($scope.beData.VoucherDateDet.dateAD ? $scope.beData.VoucherDateDet.dateAD : $scope.beData.VoucherDateDet) : new Date()
                };

                $timeout(function () {
                    $http({
                        method: 'POST',
                        url: base_url + "Account/Creation/GetVoucherNo",
                        dataType: "json",
                        data: JSON.stringify(para)
                    }).then(function (res) {
                        if (res.data.IsSuccess && res.data.Data) {
                            var vDet = res.data.Data;
                            $scope.beData.AutoManualNo = vDet.AutoManualNo;
                            $scope.beData.AutoVoucherNo = vDet.AutoVoucherNo;
                        } else {
                            alert(res.data.ResponseMSG);
                        }
                    }, function (reason) {
                        alert('Failed' + reason);
                    });
                });


                $timeout(function () {
                    $http({
                        method: 'GET',
                        url: base_url + "Account/Creation/GetVoucherModeById?voucherId=" + $scope.beData.VoucherId,
                        dataType: "json",
                        //data: JSON.stringify(para)
                    }).then(function (res) {
                        if (res.data.IsSuccess && res.data.Data) {
                            $timeout(function () {
                                $scope.SelectedVoucher = res.data.Data;
                            });
                        }
                    }, function (reason) {
                        alert('Failed' + reason);
                    });
                });
            }
        } else {
            $scope.beData.AutoManualNo = '';
            $scope.beData.AutoVoucherNo = 0;
        }

    }
    $scope.getQuotationDet = function () {

        if ($scope.beData.QuotationNo) {
            if ($scope.beData.QuotationNo.length == 0)
                return;
        } else
            return;

        $http({
            method: 'GET',
            url: base_url + "Inventory/Transaction/getBankQuotationByNo?quotationNo=" + $scope.beData.QuotationNo,
            dataType: "json"
        }).then(function (res) {
            if (res.data.IsSuccess && res.data.Data) {
                
                var vDet = res.data.Data;
                $scope.beData.BankName = vDet.BankName;
                $scope.beData.BankBranch = vDet.BankBranch;
                $scope.beData.PartyName = vDet.PartyName;
                $scope.beData.PartyAddress = vDet.PartyAddress;
                $scope.beData.MobileNo = vDet.MobileNo;
                $scope.beData.Narration = vDet.Narration;
                $scope.beData.BankQuotationTranId = vDet.TranId;
                $scope.beData.QuotationAmt = vDet.TotalAmount;
                $scope.beData.Price = 0;
                $scope.beData.EngineNo = vDet.EngineNo;
                $scope.ChangeAmt();
            } else {
                $scope.beData.BankName = '';
                $scope.beData.BankBranch = '';
                $scope.beData.PartyName = '';
                $scope.beData.PartyAddress = '';
                $scope.beData.MobileNo = '';
                $scope.beData.Narration = '';
                $scope.beData.BankQuotationTranId = null;
                $scope.beData.Price = 0;
                $scope.beData.EngineNo = '';
                alert(res.data.ResponseMSG);
                $('#txtQuotationNo').focus();
                $scope.ChangeAmt();
            }


        }, function (reason) {
            alert('Failed' + reason);
        });
    }
  
    $scope.ChangeAmt = function () {

        $scope.beData.DOPer = 0;

        if ($scope.beData.QuotationAmt && $scope.beData.QuotationAmt > 0 && $scope.beData.Price && $scope.beData.Price>0) {

            var per = ($scope.beData.Price / $scope.beData.QuotationAmt) * 100;
            $scope.beData.DOPer = per.toFixed(2);
        }
    };
    $scope.Clear = function () {

        $('input[type=file]').val(null);

        var vid = $scope.beData.VoucherId;
        var cid = $scope.beData.CostClassId;
        $scope.beData = {
            TranId: 0,
            BankQuotationTranId: null,
            QuotationNo: '',
            VoucherId: vid,
            CostClassId: cid,
            AutoVoucherNo: 0,
            AutoManualNo: '',
            VoucherDate: new Date(),
            VoucherDateDet: new Date(),
            BankName: '',
            BankBranch: '',
            PartyName: '',
            PartyAddress: '',
            MobileNo: '',
            Model: '',
            Narration: '',
            Price: 0,
            DiscountAmt: 0,
            TotalAmount: 0,
            DoRefNo: '',
            AttechFiles: []
        };

        $timeout(function () {
            $scope.getVoucherNo();
        });
        
        //$('#txtQuotationNo').focus();
        $('#cboVoucherType').focus();
    }

    $scope.SearchDataColl = [];
    $scope.SearchData = function () {

        $scope.loadingstatus = 'running';
        showPleaseWait();
        $scope.paginationOptions.TotalRows = 0;

        var sCol = $scope.paginationOptions.SearchColDet;

        var para = {
            voucherType: VoucherType,
            filter: {
                DateFrom: null,
                DateTo: null,
                PageNumber: $scope.paginationOptions.pageNumber,
                RowsOfPage: $scope.paginationOptions.pageSize,
                SearchCol: (sCol ? sCol.value : ''),
                SearchVal: $scope.paginationOptions.SearchVal,
                SearchType: (sCol ? sCol.searchType : 'text')
            }
        };

        $http({
            method: 'POST',
            url: base_url + "Inventory/Transaction/GetTransactionLst",
            dataType: "json",
            data: JSON.stringify(para)
        }).then(function (res) {
            $scope.loadingstatus = 'stop';
            hidePleaseWait();

            if (res.data.IsSuccess && res.data.Data) {
                $scope.SearchDataColl = res.data.Data;
                $scope.paginationOptions.TotalRows = res.data.TotalCount;
                $('#searVoucherRightBtn').modal('show');

            } else
                alert(res.data.ResponseMSG);

        }, function (reason) {
            alert('Failed' + reason);
        });


    };

    $scope.ReSearchData = function (pageInd) {
        if (pageInd && pageInd >= 0)
            $scope.paginationOptions.pageNumber = pageInd;
        else if (pageInd == -1)
            $scope.paginationOptions.pageNumber = 1;

        $scope.loadingstatus = 'running';
        showPleaseWait();
        $scope.paginationOptions.TotalRows = 0;
        var sCol = $scope.paginationOptions.SearchColDet;

        var para = {
            voucherType: VoucherType,
            filter: {
                DateFrom: null,
                DateTo: null,
                PageNumber: $scope.paginationOptions.pageNumber,
                RowsOfPage: $scope.paginationOptions.pageSize,
                SearchCol: (sCol ? sCol.value : ''),
                SearchVal: $scope.paginationOptions.SearchVal,
                SearchType: (sCol ? sCol.searchType : 'text')
            }
        };

        $http({
            method: 'POST',
            url: base_url + "Inventory/Transaction/GetTransactionLst",
            dataType: "json",
            data: JSON.stringify(para)
        }).then(function (res) {
            $scope.loadingstatus = 'stop';
            hidePleaseWait();

            if (res.data.IsSuccess && res.data.Data) {
                $scope.SearchDataColl = res.data.Data;
                $scope.paginationOptions.TotalRows = res.data.TotalCount;

            } else
                alert(res.data.ResponseMSG);

        }, function (reason) {
            alert('Failed' + reason);
        });

    }
});
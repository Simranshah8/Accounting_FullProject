﻿//agGrid.LicenseManager.setLicenseKey("==931880529fd1f843daf745e6af1c1637");
agGrid.initialiseAgGridWithAngular1(angular);
var app = angular.module("myApp", ['agGrid', 'angularUtils.directives.dirPagination']);

//var app = angular.module("myApp", ['agGrid', 'angularUtils.directives.dirPagination', 'cfp.hotkeys']);

app.value('companyDet',
    {
        Name: '',
        MailingName: '',
        Address: '',
        RegdNo: '',
        PanVatNo: '',
        PhoneNo: '',
        FaxNo: '',
        EmailId: '',
        WebSite: '',
        StartDateAD: '',
        EndDateAD: '',
        StartDateBS: '',
        EndDateBS: ''
    });

app.controller('mainController', function ($scope, $http,$timeout, companyDet) {
    LoadData();

    $scope.companyDet = {};
    $scope.UserType = '';
    window.OneSignal = window.OneSignal || [];

    function LoadData()
    {

       // $('#PetrolPumpModal').modal('show');

        $scope.Modules = {
            Account:false,
            Inventory: false,
            Payroll: false,
            Budget: false,
            SMS: false,
            Setup: false,
            ReportEngine: false,
            Finance: false,
            Service: false,
            Help: false,
            Enquiry: false,
            QuickAccess: false,
            IRD_Audit: false,
            MIS_Reports: false,
            App_CMS:false,
            HR: false,
            ServiceCRM:false,
        };

        $timeout(function () {
            $http({
                method: 'POST',
                url: base_url + "Setup/Security/GetUserWiseModule",
                dataType: "json"
            }).then(function (res) {
                if (res.data.IsSuccess && res.data.Data) {
                    var allowModules = mx(res.data.Data);

                    //Account, Inventory, Payroll, Budget, SMS, Setup, ReportEngine,
                      //  

                    var f1 = allowModules.firstOrDefault(p1 => p1.ModuleId == 0);
                    if (f1)
                        $scope.Modules.Account = true;

                    var f2 = allowModules.firstOrDefault(p1 => p1.ModuleId == 1);
                    if (f2)
                        $scope.Modules.Inventory = true;

                    var f3 = allowModules.firstOrDefault(p1 => p1.ModuleId == 2);
                    if (f3)
                        $scope.Modules.Payroll = true;

                    var f4 = allowModules.firstOrDefault(p1 => p1.ModuleId == 3);
                    if (f4)
                        $scope.Modules.Budget = true;

                    var f5 = allowModules.firstOrDefault(p1 => p1.ModuleId == 4);
                    if (f5)
                        $scope.Modules.SMS = true;

                    var f6 = allowModules.firstOrDefault(p1 => p1.ModuleId == 5);
                    if (f6)
                        $scope.Modules.Setup = true;

                    var f7 = allowModules.firstOrDefault(p1 => p1.ModuleId == 6);
                    if (f7)
                        $scope.Modules.ReportEngine = true;
                    
                    var f8 = allowModules.firstOrDefault(p1 => p1.ModuleId == 7);
                    if (f8)
                        $scope.Modules.Finance = true;

                    var f9 = allowModules.firstOrDefault(p1 => p1.ModuleId == 8);
                    if (f9)
                        $scope.Modules.Service = true;

                    var f10 = allowModules.firstOrDefault(p1 => p1.ModuleId == 9);
                    if (f10)
                        $scope.Modules.Help = true;

                     
                    var f11 = allowModules.firstOrDefault(p1 => p1.ModuleId == 10);
                    if (f11)
                        $scope.Modules.Enquiry = true;

                    var f12 = allowModules.firstOrDefault(p1 => p1.ModuleId == 11);
                    if (f12)
                        $scope.Modules.QuickAccess = true;

                    var f13 = allowModules.firstOrDefault(p1 => p1.ModuleId == 12);
                    if (f13)
                        $scope.Modules.IRD_Audit = true;

                    var f14 = allowModules.firstOrDefault(p1 => p1.ModuleId == 13);
                    if (f14)
                        $scope.Modules.MIS_Reports = true;

                    var f14 = allowModules.firstOrDefault(p1 => p1.ModuleId == 14);
                    if (f14)
                        $scope.Modules.App_CMS = true;

                    var f14 = allowModules.firstOrDefault(p1 => p1.ModuleId == 15);
                    if (f14)
                        $scope.Modules.HR = true;

                    var f15 = allowModules.firstOrDefault(p1 => p1.ModuleId == 16);
                    if (f15)
                        $scope.Modules.ServiceCRM = true;
                }
            }, function (reason) {
                Swal.fire('Failed' + reason);
            });
        });

        $scope.EntityColl = [];  
        $timeout(function () {
            $http({
                method: 'POST',
                url: base_url + "Setup/Security/GetEntityView",
                dataType: "json"
            }).then(function (res) {
                if (res.data.IsSuccess && res.data.Data) {                   
                    angular.forEach(res.data.Data, function (ec) {
                        if(ec.PageURL.length>0)
                            $scope.EntityColl.push(ec);
                    });  
                }
            }, function (reason) {
                Swal.fire('Failed' + reason);
            });
        });


        $scope.DashboardTypeColl = [];
        $timeout(function () {
            $http({
                method: 'POST',
                url: base_url + "Setup/ReportWriter/GetDashboardTypeForUser",
                dataType: "json"
            }).then(function (res) {
                if (res.data.IsSuccess && res.data.Data) {
                    $scope.DashboardTypeColl = res.data.Data;
                }
            }, function (reason) {
                Swal.fire('Failed' + reason);
            });
        });

        
        $scope.UserDefineRptColl = [];        
        $http.post(base_url + "Setup/ReportWriter/GetAllReportMenu").then(
            function (res)
            {
                if (res.data.IsSuccess == true) {
                    $scope.UserDefineRptColl = res.data.Data;
                }                
            }, function (reason) {
                alert('Failed: ' + reason);
        });

        $http({
            method: 'GET',
            url: base_url + "Global/GetCompanyDetail",
            dataType: "json"
        }).then(function (res) {
            if (res.data.IsSuccess && res.data.Data)
            {
                var comDet = res.data.Data;
                $scope.companyDet = comDet;

                companyDet.Name = comDet.Name;
                companyDet.MailingName = comDet.MailingName;
                companyDet.Address = comDet.Address;
                companyDet.RegdNo = comDet.RegdNo;
                companyDet.PanVatNo = comDet.PanVatNo;
                companyDet.PhoneNo = comDet.PhoneNo;
                companyDet.FaxNo = comDet.FaxNo;
                companyDet.EmailId = comDet.EmailId;
                companyDet.WebSite = comDet.WebSite;
                companyDet.StartDateAD = comDet.StartDate;
                companyDet.EndDateAD = comDet.EndDate;
                companyDet.StartDateBS = comDet.StartDateBS;
                companyDet.EndDateBS = comDet.EndDateBS;                  

            } else
                alert(res.data.ResponseMSG);

        }, function (reason) {
            alert('Failed' + reason);
        });


        $http({
            method: 'GET',
            url: base_url + "Global/GetNotificationIdKey",
            dataType: "json"
        }).then(function (res) {
            if (res.data.IsSuccess && res.data.Data) {
                var notDet = res.data.Data;
            
                OneSignal.push(function () {

                    OneSignal.sendTags({ user_id: notDet.UserId, customerCode: notDet.CustomerCode });
                    OneSignal.init({
                        appId: notDet.Id,
                        notifyButton: {
                            enable: true,
                        }
                    });

                    OneSignal.on('notificationDisplay', function (event) {

                        console.log(event);
                    });
                });

              
                OneSignal.push(["addListenerForNotificationOpened", function (data) {
                    var req = data.data;
                    if (req.status) {
                        if (req.status == 'Active') {
                        }
                    }
                    console.log("Received NotificationOpened:");
                    console.log(data);

                }]);



            } else
                alert(res.data.ResponseMSG);

        }, function (reason) {
            alert('Failed' + reason);
        });

    }

    $scope.CheckAllow = function (mid,ety, eid) {
        var isAllow = true;

        //if ($scope.query_Model) {
        //    var find = $scope.query_Model.where(p1 => p1.ModuleId == mid && p1.EntityType == ety);
        //    if (find) {
        //        var findE = find.elements.where(p1 => p1.EntityId == eid);
        //        if (findE)
        //            return true;
        //    }
        //}

        return isAllow;
    }
    $scope.ClickOnMenu = function (urlLink) {

        $.ajax({
            url: urlLink,
            success: function (data) {
                $("#divRenderbody").html(data);
            }
        });
    };

    

});

﻿app.service('GlobalServices', function ($http) {
    this.getConfirmMSG = function () {
        var confirmMSG = {
            Accept: false,
            Decline: false,
            Delete: false,
            Modify: false,
            Print: false,
            Reset: false
        };


        return confirmMSG;
    }
    this.getDateStyle = function () {

        var dataColl = [
            { id: 1, text: 'A.D.' },
            { id: 2, text: 'B.S.' }
        ];
        return dataColl;
    };
    this.getVoucherDataAs = function () {

        var dataColl = [
            { id: 1, text: 'Current Date' },
            { id: 2, text: 'Last Entry Date' }
        ];
        return dataColl;
    };
    this.getUserTypes = function () {

        var dataColl = [
            { id: 1, text: 'SYSTEMUSER' },
            { id: 2, text: 'DEALER' },
            { id: 3, text: 'SALESMAN' }
        ];
        return dataColl;
    };
    this.getDateFormat = function () {

        var dataColl = [
            { id: 1, text: 'DD-MM-YYYY' },
            { id: 2, text: 'MM-DD-YYYY' },
            { id: 3, text: 'YYYY-MM-DD' },
            { id: 4, text: 'YYYY-MM' },
            { id: 5, text: 'MM-YYYY' }
        ];
        return dataColl;
    };
     
    this.getFormActions = function () {

        var dataColl = [
            { id: 1, text: 'Save' },
            { id: 2, text: 'Modify' },
            { id: 3, text: 'Delete' },
            { id: 4, text: 'Print' },
            { id: 5, text: 'View' }
        ];
        return dataColl;
    };
    this.getRefQtyAs = function () {

        var dataColl = [
            { id: 0, text: 'LESS_THEN_EQUAL' },
            { id: 1, text: 'GREATER_THEN_EQUAL' },
            { id: 2, text: 'NOT_EDIT_ABLE' },
            { id: 3, text: 'NOT_VALIDATE' } 
        ];
        return dataColl;
    };

    this.getPaymentTypeColl = function () {

        var dataColl = [
            { id: 1, text: 'CASH' }, { id: 2, text: 'CREDIT' }
        ];
        return dataColl;
    };

    this.getAdditionDeducationSign = function () {
        var dataColl = [{ id: true, text: '+' }, { id: false, text: '-' } ];
        return dataColl;
    };
    this.getUDFTypes = function () {
        var dataColl = [{ id: 1, text: 'String' }, { id: 2, text: 'WholeNumberOnly' }, { id: 3, text: 'DecimalNumber' }, { id: 4, text: 'Date' }, { id: 5, text: 'DateTime' }, { id: 6, text: 'YesNo' },
        { id: 7, text: 'Memo' }, { id: 8, text: 'List' }];
        return dataColl;
    };
    this.getWeekDayNameList = function () {
        var dataColl = [{ id: 1, text: 'Sunday' }, { id: 2, text: 'Monday' }, { id: 3, text: 'Tuesday' }, { id: 4, text: 'Wednesday' }, { id: 5, text: 'Thursday' }, { id: 6, text: 'Friday' }, { id: 7, text: 'Saturday' }];
        return dataColl;
    };

    this.getPerPageList = function () {
        var dataColl = [{ value: 0, text: 'All' }, { value: 5, text: 5 }, { value: 10, text: 10 }, { value: 25, text: 25 }, { value: 50, text: 50 }, { value: 100, text: 100 }, { value: 500, text: 500 }];
        return dataColl;
    };

    this.getPerPageRow = function () {
        return 10;
    }
    this.getPageOptions = function ()
    {
        return [5, 10, 20, 30, 40, 50];
    }
	this.getDrCr = function () {

        var dataColl = [
            { id: 1, text: 'DR' },
            { id: 2, text: 'CR' }
        ];
        return dataColl;
    };
    this.getExpression = function () {

        var dataColl = [
            { text: "equal to", value: "==" },
            { text: "not equal to", value: "!=" },
            { text: "less than", value: "<" },
            { text: "less than equal", value: "<=" },
            { text: "greater than", value: ">" },
            { text: "greater than equal", value: ">=" },
            { text: "between", value: "between" },
            { text: "contain", value: ".Contains(" },
            { text: "StartWith", value: ".StartsWith(" },
            { text: "EndWith", value: ".EndsWith(" },
        ];

        return dataColl;
    };

    this.getLogicCondition = function () {

        var dataColl = [
            { text: "And", value: "&&" },
            { text: "Or", value: "||" } 
        ];

        return dataColl;
    };

    this.getNumberingMethod = function () {
        var dataColl = [{ text: 'Auto', value: 1, id: 1 }, { text: 'Manual', value: 2, id: 2 }, { text: 'None', value: 3, id: 3 }];
        return dataColl;
    };
    this.getSalesLedger = function () {

        return $http({
            method: 'GET',
            url: base_url + "Account/Creation/GetSalesLedger",
            dataType: "json"
        })
    };

    this.getPurchaseLedger = function () {

        return $http({
            method: 'GET',
            url: base_url + "Account/Creation/GetPurchaseLedger",
            dataType: "json"
        })
    };
    this.getSalesLedger = function (voucherId) {

        return $http({
            method: 'GET',
            url: base_url + "Account/Creation/GetSalesLedger?voucherId="+voucherId,
            dataType: "json"
        })
    };

    this.getPurchaseLedger = function (voucherId) {

        return $http({
            method: 'GET',
            url: base_url + "Account/Creation/GetPurchaseLedger?voucherId=" + voucherId,
            dataType: "json"
        })
    };
    this.getDocumentTypeList = function ()
    {
        return $http({
            method: 'POST',
            url: base_url + "Account/Creation/GetAllDocumentTypeList",
            dataType: "json"
        })
    };
    this.getButtonDisabled = function (entityId) {

        var para = {
            EntityId: entityId
        };
        return $http({
            method: 'POST',
            url: base_url + "Setup/Security/GetEntityButtonDisable",
            dataType: "json",
            data: JSON.stringify(para)
        });
    };
    this.getCompanyDet = function () {

        return $http({
            method: 'GET',
            url: base_url + "Global/GetCompanyDetail",
            dataType: "json"
        })
    };
    this.getCurrentDateTime = function () {

        return $http({
            method: 'GET',
            url: base_url + "Global/GetCurrentDate",
            dataType: "json"
        })
    };
    this.getLastEntryDate = function (voucherid) {

        return $http({
            method: 'GET',
            url: base_url + "Global/GetLastEntryDate?voucherid="+voucherid,
            dataType: "json"
        })
    };
    this.getPaymentTerms = function () {
        return $http({
            method: 'GET',
            url: base_url + "Account/Creation/GetAllPaymentTerms",
            dataType: "json"
        })
    };
    this.getFreightTypes = function () {
        return $http({
            method: 'GET',
            url: base_url + "Account/Creation/GetAllFreightType",
            dataType: "json"
        })
    };
    this.getTransactionEntity = function () {

        return $http({
            method: 'GET',
            url: base_url + "Global/GetTransactionEntityLst",
            dataType: "json"
        })
    };
    this.getReportEntity = function () {

        return $http({
            method: 'GET',
            url: base_url + "Global/GetReportEntityLst",
            dataType: "json"
        })
    };
    this.getCompanyPeriodMonth = function () {

        return $http({
            method: 'GET',
            url: base_url + "Global/GetCompanyPeriodMonth",
            dataType: "json"
        })
    };
    this.getYearList = function () {
        var dataColl = [];
        dataColl = [         
            { id: 2079, text: '2079' },
            { id: 2080, text: '2080' },
            { id: 2080, text: '2081' },
        ];


        return dataColl;
    };

    this.PrintReportData = function (EntityId, DataColl) {

        return $http({
            method: 'POST',
            url: base_url + "Global/PrintReportData",
            headers: { 'Content-Type': undefined },

            transformRequest: function (data) {

                var formData = new FormData();
                formData.append("entityId", EntityId);
                formData.append("jsonData", angular.toJson(data.jsonData));

                return formData;
            },
            data: { jsonData: DataColl }
        });
    };

});